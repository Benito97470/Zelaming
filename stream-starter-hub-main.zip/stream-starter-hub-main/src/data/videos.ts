export type Video = {
  id: string;
  title: string;
  year: number;
  genre: string;
  durationMin: number;
  popularity: number; // simple score for sorting
  synopsis: string;
  sourceUrl: string; // YouTube, Vimeo, or direct file URL
  thumbnail?: string;
};

export const videos: Video[] = [
  {
    id: "night-of-the-living-dead-1968",
    title: "Night of the Living Dead",
    year: 1968,
    genre: "Horreur",
    durationMin: 96,
    popularity: 95,
    synopsis:
      "Un classique de George A. Romero. Des survivants assiégés par des morts-vivants se réfugient dans une maison isolée.",
    sourceUrl: "https://www.youtube.com/watch?v=0TAGtIQvebs",
    thumbnail: "/src/assets/hero-stream.jpg",
  },
  {
    id: "plan-9-from-outer-space-1957",
    title: "Plan 9 from Outer Space",
    year: 1957,
    genre: "Science-fiction",
    durationMin: 79,
    popularity: 70,
    synopsis:
      "Des extraterrestres tentent de ressusciter les morts pour empêcher la destruction de l'univers.",
    sourceUrl: "https://www.youtube.com/watch?v=u2ukRYsYPmo",
    thumbnail: "/src/assets/hero-stream.jpg",
  },
  {
    id: "his-girl-friday-1940",
    title: "His Girl Friday",
    year: 1940,
    genre: "Comédie",
    durationMin: 92,
    popularity: 82,
    synopsis:
      "Une comédie rapide et brillante sur l'amour, le journalisme et les rivalités.",
    sourceUrl: "https://www.youtube.com/watch?v=mdPUIX9vcxY",
    thumbnail: "/src/assets/hero-stream.jpg",
  },
  {
    id: "charade-1963",
    title: "Charade",
    year: 1963,
    genre: "Thriller",
    durationMin: 113,
    popularity: 88,
    synopsis:
      "Avec Audrey Hepburn et Cary Grant. Une femme se retrouve au cœur d'un complot autour d'un trésor disparu.",
    sourceUrl: "https://www.youtube.com/watch?v=9V5g9f7Yl3Y",
    thumbnail: "/src/assets/hero-stream.jpg",
  },
  {
    id: "the-general-1926",
    title: "The General",
    year: 1926,
    genre: "Aventure",
    durationMin: 75,
    popularity: 77,
    synopsis:
      "Buster Keaton dans une aventure ferroviaire muette pleine d'audace et d'humour.",
    sourceUrl: "https://www.youtube.com/watch?v=XAcvAddYxvY",
    thumbnail: "/src/assets/hero-stream.jpg",
  },
  {
    id: "nosferatu-1922",
    title: "Nosferatu",
    year: 1922,
    genre: "Horreur",
    durationMin: 82,
    popularity: 90,
    synopsis:
      "Chef-d'œuvre expressionniste de Murnau, adaptation non officielle de Dracula.",
    sourceUrl: "https://www.youtube.com/watch?v=FC6jFoYm3xs",
    thumbnail: "/src/assets/hero-stream.jpg",
  },
  {
    id: "the-kid-1921",
    title: "The Kid",
    year: 1921,
    genre: "Drame",
    durationMin: 68,
    popularity: 83,
    synopsis:
      "Charlie Chaplin dans un récit tendre et drôle sur la famille.",
    sourceUrl: "https://www.youtube.com/watch?v=FE2mri1WLVQ",
    thumbnail: "/src/assets/hero-stream.jpg",
  },
  {
    id: "metropolis-1927",
    title: "Metropolis",
    year: 1927,
    genre: "Science-fiction",
    durationMin: 148,
    popularity: 92,
    synopsis:
      "Épopée futuriste et pionnière de Fritz Lang sur une ville divisée et une révolution.",
    sourceUrl: "https://www.youtube.com/watch?v=Q0NzALRJifI",
    thumbnail: "/src/assets/hero-stream.jpg",
  },
  {
    id: "sherlock-jr-1924",
    title: "Sherlock Jr.",
    year: 1924,
    genre: "Comédie",
    durationMin: 45,
    popularity: 75,
    synopsis:
      "Buster Keaton se rêve détective dans une mise en abyme inventive.",
    sourceUrl: "https://www.youtube.com/watch?v=9qz5xqhA9xY",
    thumbnail: "/src/assets/hero-stream.jpg",
  },
  {
    id: "the-phantom-of-the-opera-1925",
    title: "The Phantom of the Opera",
    year: 1925,
    genre: "Horreur",
    durationMin: 93,
    popularity: 80,
    synopsis:
      "Le classique gothique avec Lon Chaney en fantôme masqué.",
    sourceUrl: "https://www.youtube.com/watch?v=H6cV0Zl3r6A",
    thumbnail: "/src/assets/hero-stream.jpg",
  },
  {
    id: "haxan-1922",
    title: "Häxan",
    year: 1922,
    genre: "Documentaire",
    durationMin: 105,
    popularity: 68,
    synopsis:
      "Un essai visuel fascinant sur la sorcellerie et l'hystérie collective.",
    sourceUrl: "https://www.youtube.com/watch?v=r3Bq1iXjrx8",
    thumbnail: "/src/assets/hero-stream.jpg",
  },
  {
    id: "the-last-man-on-earth-1964",
    title: "The Last Man on Earth",
    year: 1964,
    genre: "Science-fiction",
    durationMin: 86,
    popularity: 73,
    synopsis:
      "Vincent Price dans une Terre ravagée par une pandémie mystérieuse.",
    sourceUrl: "https://www.youtube.com/watch?v=Q9PJlLKqYj0",
    thumbnail: "/src/assets/hero-stream.jpg",
  },
];

export const allGenres = Array.from(new Set(videos.map((v) => v.genre))).sort();
