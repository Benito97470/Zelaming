import { useMemo, useState } from "react";
import { Helmet } from "react-helmet-async";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import SearchBar from "@/components/videos/SearchBar";
import GenreFilter from "@/components/videos/GenreFilter";
import VideoGrid from "@/components/videos/VideoGrid";
import { videos } from "@/data/videos";
import { Button } from "@/components/ui/button";
import heroImg from "@/assets/hero-stream.jpg";

const Index = () => {
  const [query, setQuery] = useState("");
  const [genre, setGenre] = useState("");

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return videos
      .filter((v) => (genre ? v.genre === genre : true))
      .filter((v) => (q ? v.title.toLowerCase().includes(q) : true))
      .sort((a, b) => b.popularity - a.popularity);
  }, [query, genre]);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Helmet>
        <title>Films gratuits en streaming | Zelaming</title>
        <meta name="description" content="Regardez des films libres de droits gratuitement. Catalogue simple, gratuit et financé par la publicité." />
        <link rel="canonical" href={window.location.origin + "/"} />
      </Helmet>
      <Header />
      <main>
        <section className="relative">
          <div className="absolute inset-0">
            <img src={heroImg} alt="Ambiance cinéma, faisceaux lumineux" className="h-full w-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-background/20" />
          </div>
          <div className="relative container mx-auto py-16 sm:py-24">
            <h1 className="text-3xl sm:text-5xl font-bold max-w-3xl">
              Streaming gratuit de films du domaine public et indépendants
            </h1>
            <p className="mt-4 text-base sm:text-lg text-muted-foreground max-w-2xl">
              Un MVP pour tester l’intérêt: une sélection soignée, gratuite et financée par la publicité.
            </p>
            <div className="mt-6 flex flex-col sm:flex-row gap-3">
              <Button variant="hero" onClick={() => {
                const el = document.getElementById("catalogue");
                el?.scrollIntoView({ behavior: "smooth" });
              }}>Découvrir le catalogue</Button>
              <Button variant="outline" asChild>
                <a href="#catalogue">Parcourir</a>
              </Button>
            </div>
          </div>
        </section>

        <section id="catalogue" className="container mx-auto py-10">
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 mb-6">
            <div className="flex-1"><SearchBar value={query} onChange={setQuery} /></div>
            <GenreFilter value={genre} onChange={setGenre} />
          </div>
          <VideoGrid videos={filtered} />
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Index;
