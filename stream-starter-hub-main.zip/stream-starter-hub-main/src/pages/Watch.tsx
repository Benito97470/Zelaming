import { useMemo } from "react";
import { useParams, Link } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import ReactPlayer from "react-player";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { videos } from "@/data/videos";
import { Button } from "@/components/ui/button";

const Watch = () => {
  const { id } = useParams<{ id: string }>();
  const video = useMemo(() => videos.find((v) => v.id === id), [id]);
  const others = useMemo(() => videos.filter((v) => v.id !== id).slice(0, 8), [id]);

  if (!video) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="container mx-auto py-16 text-center">
          <h1 className="text-2xl font-semibold mb-3">Vidéo introuvable</h1>
          <p className="text-muted-foreground mb-6">Ce contenu n'existe pas (ou a été retiré).</p>
          <Button asChild>
            <Link to="/">Retour à l’accueil</Link>
          </Button>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Helmet>
        <title>{`${video.title} (${video.year}) | Zelaming`}</title>
        <meta name="description" content={`${video.title} – ${video.genre}, ${video.year}. Regardez gratuitement sur Zelaming.`} />
        <link rel="canonical" href={`${window.location.origin}/watch/${video.id}`} />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'Movie',
            name: video.title,
            genre: video.genre,
            dateCreated: video.year,
          }) }}
        />
      </Helmet>
      <Header />
      <main className="container mx-auto py-8">
        {/* Zone publicitaire simple (placeholder) */}
        <aside className="mb-4 rounded-md border p-3 text-xs text-muted-foreground">Publicité</aside>
        <article className="grid gap-6 lg:grid-cols-3 lg:items-start">
          <div className="lg:col-span-2 space-y-4">
            <div className="relative aspect-video overflow-hidden rounded-lg border">
              <ReactPlayer
                url={video.sourceUrl}
                width="100%"
                height="100%"
                controls
                playing={false}
                config={{ youtube: { playerVars: { modestbranding: 1 } } }}
              />
            </div>
            <div>
              <h1 className="text-2xl font-bold">{video.title}</h1>
              <p className="text-sm text-muted-foreground">{video.genre} · {video.year} · {video.durationMin} min</p>
              <p className="mt-3 text-sm">{video.synopsis}</p>
            </div>
          </div>
          <div className="space-y-3">
            <h2 className="text-sm font-semibold">À découvrir ensuite</h2>
            <ul className="grid gap-3">
              {others.map((v) => (
                <li key={v.id} className="rounded-md border overflow-hidden">
                  <Link to={`/watch/${v.id}`} className="flex items-center gap-3 hover:bg-accent/50">
                    <img src={v.thumbnail} alt={v.title} className="h-16 w-28 object-cover" loading="lazy" />
                    <div className="py-2 pr-2">
                      <p className="text-sm font-medium line-clamp-1">{v.title}</p>
                      <p className="text-xs text-muted-foreground">{v.genre} · {v.year}</p>
                    </div>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </article>
      </main>
      <Footer />
    </div>
  );
};

export default Watch;
