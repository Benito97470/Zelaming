const Footer = () => {
  const year = new Date().getFullYear();
  return (
    <footer className="border-t mt-12">
      <div className="container mx-auto py-8 grid gap-4 sm:grid-cols-2 items-center">
        <p className="text-sm text-muted-foreground">© {year} Zelaming · Films libres de droits</p>
        <p className="text-sm text-right text-muted-foreground">MVP – Publicité légère, catalogue restreint</p>
      </div>
    </footer>
  );
};

export default Footer;
