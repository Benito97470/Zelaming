import { Link } from "react-router-dom";
import { Video } from "@/data/videos";

type Props = {
  video: Video;
};

const VideoCard = ({ video }: Props) => {
  return (
    <Link
      to={`/watch/${video.id}`}
      className="group relative overflow-hidden rounded-lg border bg-card hover:shadow-lg transition-transform duration-300 will-change-transform"
      aria-label={`Regarder ${video.title}`}
    >
      <div className="aspect-[16/9] overflow-hidden">
        {video.thumbnail ? (
          <img
            src={video.thumbnail}
            alt={`Affiche de ${video.title}`}
            loading="lazy"
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
        ) : (
          <div className="h-full w-full bg-gradient-to-tr from-brand/20 to-brand-2/30" />
        )}
      </div>
      <div className="absolute inset-0 bg-gradient-to-t from-background/80 via-background/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
      <div className="p-3">
        <h3 className="text-sm font-medium line-clamp-1">{video.title}</h3>
        <p className="text-xs text-muted-foreground">{video.genre} · {video.year}</p>
      </div>
    </Link>
  );
};

export default VideoCard;
