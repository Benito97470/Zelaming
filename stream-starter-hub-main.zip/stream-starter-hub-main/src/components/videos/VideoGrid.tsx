import { Video } from "@/data/videos";
import VideoCard from "./VideoCard";

type Props = {
  videos: Video[];
};

const VideoGrid = ({ videos }: Props) => {
  if (!videos.length) {
    return (
      <div className="text-center py-16 text-muted-foreground">Aucun contenu ne correspond à votre recherche.</div>
    );
  }
  return (
    <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
      {videos.map((v) => (
        <VideoCard key={v.id} video={v} />
      ))}
    </div>
  );
};

export default VideoGrid;
