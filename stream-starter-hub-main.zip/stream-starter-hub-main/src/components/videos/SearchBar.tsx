import { ChangeEvent } from "react";
import { Input } from "@/components/ui/input";

type Props = {
  value: string;
  onChange: (v: string) => void;
};

const SearchBar = ({ value, onChange }: Props) => {
  const handle = (e: ChangeEvent<HTMLInputElement>) => onChange(e.target.value);
  return (
    <div className="w-full">
      <Input
        value={value}
        onChange={handle}
        placeholder="Rechercher un titre..."
        aria-label="Rechercher un titre"
      />
    </div>
  );
};

export default SearchBar;
