import { allGenres } from "@/data/videos";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

type Props = {
  value: string;
  onChange: (v: string) => void;
};

const GenreFilter = ({ value, onChange }: Props) => {
  return (
    <Select value={value || undefined} onValueChange={(v) => onChange(v === "all" ? "" : v)}>
      <SelectTrigger className="w-[200px]">
        <SelectValue placeholder="Genre" />
      </SelectTrigger>
      <SelectContent className="z-[60] bg-popover">
        <SelectItem value="all">Tous les genres</SelectItem>
        {allGenres.map((g) => (
          <SelectItem key={g} value={g}>{g}</SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
};

export default GenreFilter;
